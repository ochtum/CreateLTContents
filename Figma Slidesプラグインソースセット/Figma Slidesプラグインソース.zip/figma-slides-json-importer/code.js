const SLIDE_WIDTH = 1920;
const SLIDE_HEIGHT = 1080;
const MARGIN_X = 120;
const MARGIN_Y = 110;
const DEFAULT_THEME = {
  primary: "#1A5E2A",
  secondary: "#2E7D32",
  accent: "#1976D2",
  danger: "#D32F2F",
  bg: "#F7FAF7",
  text: "#1A1A1A"
};

let fonts = null;

try {
  // `themeColors` can fail in some older plugin runtimes; keep options minimal.
  figma.showUI(__html__, { width: 480, height: 680 });
} catch (error) {
  figma.closePlugin(`Failed to open plugin UI: ${formatError(error)}`);
}

figma.ui.onmessage = async (message) => {
  try {
    if (!message || typeof message !== "object") return;

    if (message.type === "import-json") {
      const result = await importFromJson(message.payload);
      figma.notify(`${result} slides imported.`);
      figma.ui.postMessage({ type: "import-complete", success: true, count: result });
      return;
    }

    if (message.type === "close") {
      figma.closePlugin();
    }
  } catch (error) {
    const msg = formatError(error);
    figma.notify(`Import failed: ${msg}`, { error: true });
    figma.ui.postMessage({ type: "import-complete", success: false, error: msg });
  }
};

async function importFromJson(payload) {
  if (figma.editorType !== "slides") {
    throw new Error("This plugin works only in Figma Slides files. Open a Slides file and run again.");
  }
  if (typeof figma.createSlide !== "function") {
    throw new Error("`createSlide` API is not available. Update Figma Desktop/Web to the latest version.");
  }

  const parsed = parseInput(payload);
  const themeOverrides = parsed.document && parsed.document.theme ? parsed.document.theme : null;
  const theme = mergeTheme(DEFAULT_THEME, themeOverrides);

  if (!Array.isArray(parsed.slides) || parsed.slides.length === 0) {
    throw new Error("`slides` must be a non-empty array.");
  }

  await ensureFontsLoaded();

  const createdSlides = [];
  for (const [index, slideData] of parsed.slides.entries()) {
    const slide = figma.createSlide();
    slide.name = buildSlideName(index, slideData);
    setSlideBackground(slide, theme.bg);
    await renderSlide(slide, slideData, theme);
    createdSlides.push(slide);
  }

  if (createdSlides.length > 0) {
    figma.currentPage.selection = [createdSlides[0]];
    figma.viewport.scrollAndZoomIntoView(createdSlides);
  }

  return createdSlides.length;
}

function parseInput(payload) {
  if (typeof payload === "string") {
    const sanitized = sanitizeJsonLikeText(payload);
    try {
      return JSON.parse(sanitized);
    } catch (error) {
      throw new Error("Invalid JSON format. Paste raw JSON only (no markdown/code fence/comments).");
    }
  }
  if (payload && typeof payload === "object") {
    return payload;
  }
  throw new Error("Input is empty.");
}

function sanitizeJsonLikeText(text) {
  let value = text;
  if (!value) return value;

  // Remove UTF-8 BOM if present.
  if (value.charCodeAt(0) === 0xfeff) {
    value = value.slice(1);
  }

  value = value.trim();

  // Accept markdown fenced blocks: ```json ... ```
  if (value.indexOf("```") === 0) {
    value = value.replace(/^```[a-zA-Z0-9_-]*\s*/, "");
    value = value.replace(/\s*```$/, "");
  }

  // Accept accidental list marker before JSON object/array, e.g. "• { ... }" or "- { ... }"
  value = value.replace(/^[\u2022\-*]\s*(?=[\[{])/, "");

  return value.trim();
}

function buildSlideName(index, slideData) {
  if (slideData && typeof slideData.title === "string" && slideData.title.trim().length > 0) {
    return `${index + 1}. ${slideData.title.trim()}`;
  }
  return `Slide ${index + 1}`;
}

function setSlideBackground(slide, hexColor) {
  const color = hexToPaintColor(hexColor, { r: 0.97, g: 0.98, b: 0.97 });
  try {
    slide.fills = [{ type: "SOLID", color }];
  } catch (error) {
    // Some Slides builds may not expose mutable fills on SlideNode.
  }
}

async function renderSlide(slide, slideData, theme) {
  const layout = stringOr(slideData.layout, "bullets").toLowerCase();

  switch (layout) {
    case "title":
      await renderTitleLayout(slide, slideData, theme);
      break;
    case "section":
      await renderSectionLayout(slide, slideData, theme);
      break;
    case "two-column":
      await renderTwoColumnLayout(slide, slideData, theme);
      break;
    case "code":
      await renderCodeLayout(slide, slideData, theme);
      break;
    case "timeline":
      await renderTimelineLayout(slide, slideData, theme);
      break;
    case "checklist":
      await renderChecklistLayout(slide, slideData, theme);
      break;
    case "closing":
      await renderClosingLayout(slide, slideData, theme);
      break;
    case "bullets":
    default:
      await renderBulletLayout(slide, slideData, theme);
      break;
  }
}

async function renderTitleLayout(slide, data, theme) {
  await addText(slide, stringOr(data.title, ""), {
    x: MARGIN_X,
    y: 320,
    width: SLIDE_WIDTH - MARGIN_X * 2,
    fontSize: 72,
    bold: true,
    color: theme.primary,
    align: "CENTER"
  });

  await addText(slide, stringOr(data.subtitle, ""), {
    x: MARGIN_X + 80,
    y: 460,
    width: SLIDE_WIDTH - (MARGIN_X + 80) * 2,
    fontSize: 32,
    color: theme.text,
    align: "CENTER"
  });

  const body = safeArray(data.body);
  if (body.length > 0) {
    await addText(slide, body.join("\n"), {
      x: MARGIN_X + 120,
      y: 620,
      width: SLIDE_WIDTH - (MARGIN_X + 120) * 2,
      fontSize: 24,
      color: theme.text,
      align: "CENTER"
    });
  }
}

async function renderSectionLayout(slide, data, theme) {
  await addText(slide, stringOr(data.title, ""), {
    x: MARGIN_X,
    y: MARGIN_Y + 30,
    width: SLIDE_WIDTH - MARGIN_X * 2,
    fontSize: 62,
    bold: true,
    color: theme.primary
  });
  await addBulletList(slide, safeArray(data.body), {
    x: MARGIN_X + 10,
    y: 310,
    width: SLIDE_WIDTH - (MARGIN_X + 10) * 2,
    fontSize: 34,
    lineGap: 18,
    color: theme.text
  });
}

async function renderBulletLayout(slide, data, theme) {
  await addText(slide, stringOr(data.title, ""), {
    x: MARGIN_X,
    y: MARGIN_Y,
    width: SLIDE_WIDTH - MARGIN_X * 2,
    fontSize: 54,
    bold: true,
    color: theme.primary
  });

  if (typeof data.subtitle === "string" && data.subtitle.trim().length > 0) {
    await addText(slide, data.subtitle, {
      x: MARGIN_X,
      y: MARGIN_Y + 98,
      width: SLIDE_WIDTH - MARGIN_X * 2,
      fontSize: 28,
      color: theme.secondary
    });
  }

  await addBulletList(slide, safeArray(data.body), {
    x: MARGIN_X + 10,
    y: 290,
    width: SLIDE_WIDTH - (MARGIN_X + 10) * 2,
    fontSize: 32,
    lineGap: 16,
    color: theme.text
  });
}

async function renderTwoColumnLayout(slide, data, theme) {
  await addText(slide, stringOr(data.title, ""), {
    x: MARGIN_X,
    y: MARGIN_Y,
    width: SLIDE_WIDTH - MARGIN_X * 2,
    fontSize: 52,
    bold: true,
    color: theme.primary
  });

  const gutter = 60;
  const columnWidth = (SLIDE_WIDTH - MARGIN_X * 2 - gutter) / 2;
  const leftX = MARGIN_X;
  const rightX = MARGIN_X + columnWidth + gutter;

  const left = data.left || {};
  const right = data.right || {};

  await addText(slide, stringOr(left.heading, "Left"), {
    x: leftX,
    y: 250,
    width: columnWidth,
    fontSize: 34,
    bold: true,
    color: theme.secondary
  });
  await addBulletList(slide, safeArray(left.points), {
    x: leftX,
    y: 310,
    width: columnWidth,
    fontSize: 27,
    lineGap: 14,
    color: theme.text
  });

  await addText(slide, stringOr(right.heading, "Right"), {
    x: rightX,
    y: 250,
    width: columnWidth,
    fontSize: 34,
    bold: true,
    color: theme.secondary
  });
  await addBulletList(slide, safeArray(right.points), {
    x: rightX,
    y: 310,
    width: columnWidth,
    fontSize: 27,
    lineGap: 14,
    color: theme.text
  });
}

async function renderCodeLayout(slide, data, theme) {
  await addText(slide, stringOr(data.title, ""), {
    x: MARGIN_X,
    y: MARGIN_Y,
    width: SLIDE_WIDTH - MARGIN_X * 2,
    fontSize: 52,
    bold: true,
    color: theme.primary
  });

  const codeBg = figma.createRectangle();
  codeBg.x = MARGIN_X;
  codeBg.y = 260;
  codeBg.resize(SLIDE_WIDTH - MARGIN_X * 2, SLIDE_HEIGHT - 360);
  codeBg.cornerRadius = 16;
  codeBg.fills = [{ type: "SOLID", color: hexToPaintColor("#0F172A", { r: 0.06, g: 0.09, b: 0.16 }) }];
  codeBg.strokes = [{ type: "SOLID", color: hexToPaintColor(theme.accent, { r: 0.1, g: 0.4, b: 0.8 }) }];
  codeBg.strokeWeight = 2;
  slide.appendChild(codeBg);

  const code = stringOr(data.code, "");
  await addText(slide, code, {
    x: MARGIN_X + 34,
    y: 300,
    width: SLIDE_WIDTH - MARGIN_X * 2 - 68,
    fontSize: 24,
    mono: true,
    color: "#F8FAFC"
  });
}

async function renderTimelineLayout(slide, data, theme) {
  await addText(slide, stringOr(data.title, ""), {
    x: MARGIN_X,
    y: MARGIN_Y,
    width: SLIDE_WIDTH - MARGIN_X * 2,
    fontSize: 52,
    bold: true,
    color: theme.primary
  });

  const steps = safeArray(data.steps);
  const lines = steps.map((s, i) => `${i + 1}. ${s}`);
  await addBulletList(slide, lines, {
    x: MARGIN_X + 10,
    y: 270,
    width: SLIDE_WIDTH - (MARGIN_X + 10) * 2,
    fontSize: 32,
    lineGap: 18,
    color: theme.text,
    customBullet: false
  });
}

async function renderChecklistLayout(slide, data, theme) {
  await addText(slide, stringOr(data.title, ""), {
    x: MARGIN_X,
    y: MARGIN_Y,
    width: SLIDE_WIDTH - MARGIN_X * 2,
    fontSize: 52,
    bold: true,
    color: theme.primary
  });

  const items = safeArray(data.items).map((item) => `□ ${item}`);
  await addBulletList(slide, items, {
    x: MARGIN_X + 10,
    y: 280,
    width: SLIDE_WIDTH - (MARGIN_X + 10) * 2,
    fontSize: 34,
    lineGap: 14,
    color: theme.text,
    customBullet: false
  });

  if (typeof data.footer === "string" && data.footer.trim().length > 0) {
    await addText(slide, data.footer, {
      x: MARGIN_X,
      y: SLIDE_HEIGHT - 150,
      width: SLIDE_WIDTH - MARGIN_X * 2,
      fontSize: 28,
      bold: true,
      color: theme.secondary
    });
  }
}

async function renderClosingLayout(slide, data, theme) {
  await renderBulletLayout(slide, data, theme);
  const refs = safeArray(data.references);
  if (refs.length > 0) {
    await addText(slide, "References", {
      x: MARGIN_X,
      y: SLIDE_HEIGHT - 240,
      width: SLIDE_WIDTH - MARGIN_X * 2,
      fontSize: 24,
      bold: true,
      color: theme.secondary
    });
    await addText(slide, refs.join("\n"), {
      x: MARGIN_X,
      y: SLIDE_HEIGHT - 205,
      width: SLIDE_WIDTH - MARGIN_X * 2,
      fontSize: 18,
      color: theme.text
    });
  }
}

async function addBulletList(slide, lines, options) {
  const filtered = lines.filter((line) => typeof line === "string" && line.trim().length > 0);
  if (filtered.length === 0) return;

  const useBullets = options.customBullet !== false;
  const text = useBullets ? filtered.map((line) => `• ${line}`).join("\n\n") : filtered.join("\n\n");
  await addText(slide, text, options);
}

async function addText(slide, text, options) {
  const value = typeof text === "string" ? text : "";
  if (!value.trim()) return null;

  const node = figma.createText();
  node.x = numOr(options.x, 0);
  node.y = numOr(options.y, 0);
  node.resize(numOr(options.width, 800), 20);
  node.textAutoResize = "HEIGHT";
  node.textAlignHorizontal = options.align === "CENTER" ? "CENTER" : "LEFT";
  node.fontSize = numOr(options.fontSize, 24);
  node.lineHeight = {
    unit: "PIXELS",
    value: numOr(options.fontSize, 24) + numOr(options.lineGap, 10)
  };

  const fontName = options.mono ? fonts.mono : options.bold ? fonts.bold : fonts.regular;
  node.fontName = fontName;
  node.fills = [{ type: "SOLID", color: hexToPaintColor(options.color, { r: 0.1, g: 0.1, b: 0.1 }) }];
  node.characters = value;
  slide.appendChild(node);
  return node;
}

async function ensureFontsLoaded() {
  if (fonts) return;

  const available = await figma.listAvailableFontsAsync();
  const familyOrder = ["Inter", "Noto Sans JP", "Roboto", "Arial"];
  let family = "Inter";
  for (const f of familyOrder) {
    if (available.some((a) => a.fontName.family === f)) {
      family = f;
      break;
    }
  }

  const stylesForFamily = available
    .filter((a) => a.fontName.family === family)
    .map((a) => a.fontName.style);

  const regularStyle = pickStyle(stylesForFamily, ["Regular", "Book", "Medium"]);
  const boldStyle = pickStyle(stylesForFamily, ["Bold", "Semibold", "Medium", regularStyle]);
  const monoFamily = available.some((a) => a.fontName.family === "Roboto Mono") ? "Roboto Mono" : family;
  const monoStyles = available
    .filter((a) => a.fontName.family === monoFamily)
    .map((a) => a.fontName.style);
  const monoStyle = pickStyle(monoStyles, ["Regular", "Medium", "Book"]);

  fonts = {
    regular: { family, style: regularStyle },
    bold: { family, style: boldStyle },
    mono: { family: monoFamily, style: monoStyle }
  };

  await figma.loadFontAsync(fonts.regular);
  await figma.loadFontAsync(fonts.bold);
  await figma.loadFontAsync(fonts.mono);
}

function pickStyle(styles, preferred) {
  for (const style of preferred) {
    if (styles.includes(style)) return style;
  }
  if (styles.length > 0) return styles[0];
  return "Regular";
}

function hexToPaintColor(hex, fallback) {
  if (typeof hex !== "string") return fallback;
  const normalized = hex.trim().replace(/^#/, "");
  if (!/^[0-9a-fA-F]{6}$/.test(normalized)) return fallback;

  const r = parseInt(normalized.slice(0, 2), 16) / 255;
  const g = parseInt(normalized.slice(2, 4), 16) / 255;
  const b = parseInt(normalized.slice(4, 6), 16) / 255;
  return { r, g, b };
}

function stringOr(value, fallback) {
  return typeof value === "string" ? value : fallback;
}

function safeArray(value) {
  if (!Array.isArray(value)) return [];
  return value.filter((item) => typeof item === "string");
}

function numOr(value, fallback) {
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}

function formatError(error) {
  if (error instanceof Error) {
    if (error.stack && error.stack.length > 0) return `${error.message}\n${error.stack}`;
    return error.message;
  }
  return "Unknown error.";
}

function mergeTheme(baseTheme, overrideTheme) {
  const merged = {};
  const keys = ["primary", "secondary", "accent", "danger", "bg", "text"];
  for (let i = 0; i < keys.length; i += 1) {
    const key = keys[i];
    if (overrideTheme && typeof overrideTheme[key] === "string") {
      merged[key] = overrideTheme[key];
    } else {
      merged[key] = baseTheme[key];
    }
  }
  return merged;
}
