# Slides JSON Importer (Figma Slides)

Figma Slidesで、構造化JSONからスライドを自動生成する開発用プラグインです。

## 1. ファイル構成

- `figma-slides-json-importer/manifest.json`
- `figma-slides-json-importer/code.js`
- `figma-slides-json-importer/ui.html`

## 2. Figma側のアドオン設定手順

1. Figma Desktop または Web で任意の **Slidesファイル**を開く  
2. メニューから `Plugins` -> `Development` -> `Import plugin from manifest...` を選択  
3. このプロジェクトの `figma-slides-json-importer/manifest.json` を指定  
4. 読み込み後、`Plugins` -> `Development` -> `Slides JSON Importer` を実行

## 3. JSON取り込み手順

1. プラグインUIでJSONを貼り付ける（または `JSONファイルを選択`）
2. `Import` を押す
3. `slides` 配列の順にスライドが追加生成される

## 4. 対応レイアウト

- `title`
- `section`
- `bullets`
- `two-column`
- `code`
- `timeline`
- `checklist`
- `closing`

## 5. 想定JSON（最小）

```json
{
  "document": {
    "title": "Demo",
    "theme": {
      "primary": "#1A5E2A",
      "bg": "#F7FAF7",
      "text": "#1A1A1A"
    }
  },
  "slides": [
    {
      "layout": "title",
      "title": "タイトル",
      "subtitle": "サブタイトル"
    },
    {
      "layout": "bullets",
      "title": "要点",
      "body": ["ポイント1", "ポイント2"]
    }
  ]
}
```

## 6. 備考

- フォントは利用可能なものから `Inter` 優先で自動選択します。
- `slides` 配列が空の場合はインポートを中断します。
- 本プラグインは **Figma Slidesファイル専用**です（Design/FigJamでは実行不可）。
